=== AI Blog Generator PRO ===
Contributors: ai
Requires at least: 6.0
Tested up to: 6.5
Requires PHP: 8.0
Stable tag: 1.0.0
License: GPLv2 or later

Generator automat de articole + imagini + SEO + WooCommerce bulk, cu programare și auto-publish.

== Description ==
- Generate tab: articole AI + featured image Unsplash
- SEO: Keyword queue (Valul 1), integrare Ahrefs/SEMrush (Valul 2)
- WooCommerce: bulk descrieri
- Settings: API keys, auto-schedule, industries, light/dark

== Installation ==
1. Arhivează folderul `ai-blog-generator-pro`
2. Upload la Plugins → Add New → Upload
3. Activează
4. Mergi în AI Blog Generator → Settings și adaugă OpenAI/Unsplash keys

== Changelog ==
= 1.0.0 =
- Prima versiune
