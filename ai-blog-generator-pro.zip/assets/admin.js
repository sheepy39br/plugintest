(function($){
  $(document).on('click', '.ai-bgpro-topbar .mode-toggle', function(e){
    e.preventDefault();
    // (opțional) se poate face toggle temă via AJAX + user_meta
  });
})(jQuery);
